package com.capgemini.empwebapp.service;

public interface EmployeeService {

}
